"""Configuration management for AI Control Tower SDK.

Enforces strict configuration precedence:
1. Explicit arguments passed to ControlTower(...) or init(...)
2. Environment variables (CONTROL_TOWER_*)
3. Optional configuration file (~/.control_tower.toml)

Uses ONLY the standard library (with pure stdlib TOML parsing for Python 3.9/3.10 fallback).
"""
import os
import re
from pathlib import Path
from typing import Any

# Try Python 3.11+ tomllib
try:
    import tomllib
except ImportError:
    tomllib = None  # type: ignore


DEFAULT_CONFIG_PATH = Path.home() / ".control_tower.toml"


class SdkConfig:
    """Resolved SDK configuration values."""

    def __init__(
        self,
        url: str | None = None,
        api_key: str | None = None,
        agent_name: str | None = None,
        environment: str | None = None,
        mode: str | None = None,
        disabled: bool | None = None,
        heartbeat_seconds: int | None = None,
        log_level: str | None = None,
        allow_insecure: bool = False,
        strict: bool = False,
        probe_imds: bool = False,
        config_path: Path | str | None = None,
    ):
        # 1. Load file config (lowest priority)
        file_cfg = _load_toml_config(config_path or os.environ.get("CONTROL_TOWER_CONFIG_FILE") or DEFAULT_CONFIG_PATH)

        # 2. Helper to resolve with precedence: explicit > env > file > default
        def resolve(explicit: Any, env_var: str, file_key: str, default: Any) -> Any:
            if explicit is not None:
                return explicit
            env_val = os.environ.get(env_var)
            if env_val is not None and env_val.strip() != "":
                return env_val.strip()
            if file_key in file_cfg and file_cfg[file_key] is not None:
                return file_cfg[file_key]
            return default

        self.url = resolve(url, "CONTROL_TOWER_URL", "url", "http://localhost:8000").rstrip("/")
        self.api_key = resolve(api_key, "CONTROL_TOWER_API_KEY", "api_key", "")
        self.agent_name = resolve(agent_name, "CONTROL_TOWER_AGENT_NAME", "agent_name", None)
        self.environment = resolve(environment, "CONTROL_TOWER_ENVIRONMENT", "environment", "Production")
        self.mode = resolve(mode, "CONTROL_TOWER_MODE", "mode", "auto")

        # Disabled boolean
        env_disabled = os.environ.get("CONTROL_TOWER_DISABLED")
        if (
            disabled is True
            or (env_disabled and env_disabled.lower() in ("1", "true", "yes"))
            or (file_cfg.get("disabled") is True and disabled is not False)
        ):
            self.disabled = True
        else:
            self.disabled = False

        # Heartbeat seconds (int)
        raw_hb = resolve(heartbeat_seconds, "CONTROL_TOWER_HEARTBEAT_SECONDS", "heartbeat_seconds", 60)
        try:
            self.heartbeat_seconds = max(5, int(raw_hb))
        except (ValueError, TypeError):
            self.heartbeat_seconds = 60

        # Log level
        self.log_level = resolve(log_level, "CONTROL_TOWER_LOG_LEVEL", "log_level", "WARNING").upper()

        # Insecure & strict flags
        env_insecure = os.environ.get("CONTROL_TOWER_ALLOW_INSECURE")
        self.allow_insecure = allow_insecure or (env_insecure and env_insecure.lower() in ("1", "true", "yes"))
        self.strict = strict

        # IMDS probing
        env_imds = os.environ.get("CONTROL_TOWER_PROBE_IMDS")
        self.probe_imds = probe_imds or (env_imds and env_imds.lower() in ("1", "true", "yes"))

    @property
    def masked_api_key(self) -> str:
        """Returns the key prefix followed by dots (e.g. act_live_196...), never the full key."""
        if not self.api_key:
            return "<none>"
        prefix = self.api_key[:12] if len(self.api_key) >= 12 else self.api_key[:4]
        return f"{prefix}..."


def _load_toml_config(path: Path | str) -> dict[str, Any]:
    """Loads ~/.control_tower.toml using tomllib or fallback pure stdlib parser."""
    p = Path(path)
    if not p.is_file():
        return {}

    try:
        content = p.read_text(encoding="utf-8")
        if tomllib:
            raw = tomllib.loads(content)
            # Flatten [control_tower] section or root
            if "control_tower" in raw and isinstance(raw["control_tower"], dict):
                return raw["control_tower"]
            return raw
        else:
            return _parse_simple_toml(content)
    except Exception:
        return {}


def _parse_simple_toml(content: str) -> dict[str, Any]:
    """Minimal stdlib TOML key-value parser for Python 3.9/3.10 without dependencies."""
    result: dict[str, Any] = {}
    in_section = True
    for line in content.splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        if line.startswith("["):
            section_name = line.strip("[]").strip()
            in_section = section_name in ("control_tower", "default")
            continue
        if in_section and "=" in line:
            parts = line.split("=", 1)
            k = parts[0].strip()
            v = parts[1].strip()
            # Parse quotes
            if (v.startswith('"') and v.endswith('"')) or (v.startswith("'") and v.endswith("'")):
                result[k] = v[1:-1]
            elif v.lower() in ("true", "false"):
                result[k] = v.lower() == "true"
            elif re.match(r"^-?\d+$", v):
                result[k] = int(v)
            else:
                result[k] = v
    return result


def write_toml_config(url: str, api_key: str, path: Path | str = DEFAULT_CONFIG_PATH) -> None:
    """Writes a configuration file to ~/.control_tower.toml with restrictive permissions (0600)."""
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    content = (
        f"# AI Control Tower configuration file\n"
        f"[control_tower]\n"
        f'url = "{url.rstrip("/")}"\n'
        f'api_key = "{api_key}"\n'
        f"heartbeat_seconds = 60\n"
    )
    p.write_text(content, encoding="utf-8")
    try:
        os.chmod(p, 0o600)  # Owner read/write only
    except Exception:
        pass
