"""Official Python client for AI Control Tower.

Zero third-party dependencies: strictly uses Python >= 3.9 standard library.
Ensures total host application safety: non-blocking, non-raising by default,
safe with multi-process worker forks (gunicorn/uvicorn), and automatic environment detection.
"""
import atexit
import functools
import json
import logging
import os
import random
import socket
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid
from collections import deque
from collections.abc import Callable, Generator
from contextlib import contextmanager
from typing import Any

from control_tower_sdk.config import SdkConfig
from control_tower_sdk.detect import detect

logger = logging.getLogger("control_tower_sdk")


class ControlTowerError(Exception):
    """Base exception for Control Tower SDK operations."""

    def __init__(
        self,
        message: str,
        status_code: int | None = None,
        response_body: str | None = None,
    ):
        super().__init__(message)
        self.status_code = status_code
        self.response_body = response_body


class AgentSession:
    """Represents an active agent execution session."""

    def __init__(self, client: "ControlTower", agent_data: dict[str, Any]):
        self.client = client
        self.agent_data = agent_data
        self.agent_id: str = agent_data.get("agent_id", "")
        self.name: str = agent_data.get("name", "")
        self.status: str = agent_data.get("status", "")
        self.risk_tier: str = agent_data.get("risk_tier", "")

    def heartbeat(
        self,
        metrics: dict[str, Any] | None = None,
        status: str | None = None,
    ) -> dict[str, Any] | None:
        """Emits a heartbeat during this session."""
        return self.client.heartbeat_once(metrics=metrics, status=status)


class AgentHandle:
    """Represents a distinct agent hosted inside the current Python process.

    Shares network configuration, instance_id, and background heartbeat thread
    with the parent ControlTower client.
    """

    def __init__(
        self,
        tower: "ControlTower",
        name: str,
        description: str | None = None,
        framework: str | None = None,
        llms: list[str] | None = None,
        purpose: str | None = None,
        repo_url: str | None = None,
        tags: list[str] | None = None,
        environment: str | None = None,
        **kwargs: Any,
    ):
        self.tower = tower
        self.name = name
        self.description = description
        self.framework = framework
        self.llms = llms or kwargs.get("llm_models") or []
        self.purpose = purpose
        self.repo_url = repo_url
        self.tags = tags or []
        self.environment = environment or tower.environment
        self.agent_id: str | None = kwargs.get("agent_id")
        self.fingerprint: str | None = kwargs.get("fingerprint")
        self.extra_kwargs = kwargs

    def register(
        self,
        description: str | None = None,
        purpose: str | None = None,
        framework: str | None = None,
        llms: list[str] | None = None,
        repo_url: str | None = None,
        tags: list[str] | None = None,
        **kwargs: Any,
    ) -> str | None:
        """Idempotently registers this agent with AI Control Tower."""
        return self.tower._register_agent_handle(
            self,
            description=description or self.description,
            purpose=purpose or self.purpose,
            framework=framework or self.framework,
            llms=llms or self.llms,
            repo_url=repo_url or self.repo_url,
            tags=tags or self.tags,
            **kwargs,
        )

    def heartbeat_once(
        self,
        metrics: dict[str, Any] | None = None,
        status: str | None = None,
        uptime: float | None = None,
    ) -> dict[str, Any] | None:
        """Synchronously transmits an immediate heartbeat for this agent."""
        return self.tower._heartbeat_agent_handle(
            self,
            metrics=metrics,
            status=status,
            uptime=uptime,
        )

    def track_llm_call(
        self,
        provider: str,
        model: str,
        input_tokens: int = 0,
        output_tokens: int = 0,
        latency_ms: float = 0.0,
        status: str = "success",
        error_message: str | None = None,
    ) -> None:
        """Records an LLM call event associated with this agent."""
        self.tower.track_llm_call(
            provider=provider,
            model=model,
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            latency_ms=latency_ms,
            status=status,
            error_message=error_message,
            agent_id=self.agent_id,
        )

    def __repr__(self) -> str:
        return f"<AgentHandle name='{self.name}' id='{self.agent_id}' framework='{self.framework}'>"


class ControlTower:
    """Enterprise AI Control Tower governance client."""

    def __init__(
        self,
        url: str | None = None,
        api_key: str | None = None,
        agent_name: str | None = None,
        environment: str | None = None,
        mode: str = "auto",
        disabled: bool = False,
        strict: bool = False,
        allow_insecure: bool = False,
        heartbeat_seconds: int | None = None,
        **options: Any,
    ):
        resolved_url = url or options.get("base_url")
        if api_key is not None and not api_key.strip():
            raise ValueError("api_key must be non-empty")

        # Resolve configuration with precedence: explicit > env > ~/.control_tower.toml
        self.config = SdkConfig(
            url=resolved_url,
            api_key=api_key,
            agent_name=agent_name,
            environment=environment,
            mode=mode,
            disabled=disabled,
            heartbeat_seconds=heartbeat_seconds,
            allow_insecure=allow_insecure,
            strict=strict,
            probe_imds=options.get("probe_imds", False),
        )

        # Configure logger level
        log_level = getattr(logging, self.config.log_level, logging.WARNING)
        logger.setLevel(log_level)

        self.url = self.config.url
        self.api_key = self.config.api_key
        self.disabled = self.config.disabled
        self.strict = self.config.strict
        self.heartbeat_seconds = self.config.heartbeat_seconds

        # Enforce HTTPS security rule
        self._validate_url_security()

        # Runtime & process identification
        self._created_pid = os.getpid()
        self.instance_id = self._generate_instance_id()

        # Agent registration state
        self.agent_name = (
            self.config.agent_name
            or options.get("name")
            or "Autonomous Agent"
        )
        self.environment = self.config.environment or "Production"
        self.agent_id: str | None = options.get("agent_id")
        self.fingerprint: str | None = options.get("fingerprint")

        # Lazy environment detection (avoids network probe in __init__)
        self._detected_env: dict[str, Any] | None = None
        self.mode = self._resolve_mode(self.config.mode)

        # Background worker state
        self._queue: deque[tuple[str, dict[str, Any]]] = deque(maxlen=100)
        self._events_queue: deque[dict[str, Any]] = deque(maxlen=1000)
        self._agent_handles: dict[str, AgentHandle] = {}
        self._lock = threading.Lock()
        self._events_lock = threading.Lock()
        self._stop_event = threading.Event()
        self._thread: threading.Thread | None = None
        self._is_started = False

        # Register quick atexit flush
        atexit.register(self._atexit_handler)

    @property
    def base_url(self) -> str:
        return self.url

    def __repr__(self) -> str:
        return (
            f"<ControlTower url='{self.url}' "
            f"key='{self.config.masked_api_key}' "
            f"agent='{self.agent_name}' "
            f"mode='{self.mode}' "
            f"disabled={self.disabled}>"
        )

    # -------------------------------------------------------------------------
    # Public Core API
    # -------------------------------------------------------------------------

    def register(
        self,
        description: str | None = None,
        purpose: str | None = None,
        framework: str | None = None,
        llms: list[str] | None = None,
        repo_url: str | None = None,
        tags: list[str] | None = None,
        **kwargs: Any,
    ) -> str | None:
        """Idempotently registers this agent with AI Control Tower.

        Safe and non-raising by default: returns agent_id string on success or None on failure.
        """
        if self.disabled:
            return self.agent_id or "disabled-agent-id"

        if self._detected_env is None:
            self._detected_env = detect(redact=True, probe_imds=bool(self.config.probe_imds))

        payload = {
            "name": self.agent_name,
            "agent_name": self.agent_name,
            "environment": self.environment,
            "description": description or f"Agent self-registered from {self._detected_env.get('cloud', {}).get('platform', 'host')}.",
            "purpose": purpose or "",
            "framework": framework or self._detected_env.get("application", {}).get("framework", "custom"),
            "llms": llms or kwargs.get("llm_models") or [],
            "repo_url": repo_url or self._detected_env.get("git", {}).get("repo_url"),
            "tags": tags or [],
            "instance_id": self.instance_id,
            "sdk_version": "0.2.0",
            "fingerprint": self.fingerprint,
            "environment_details": self._detected_env,
        }

        try:
            resp = self._post("/api/v1/sdk/register", payload)
            self.agent_id = resp.get("agent_id")
            if resp.get("fingerprint"):
                self.fingerprint = resp.get("fingerprint")
            logger.info("Agent registered successfully: %s (id=%s)", self.agent_name, self.agent_id)
            return self.agent_id
        except Exception as exc:
            self._handle_error(f"Failed to register agent '{self.agent_name}': {exc}", exc)
            return self.agent_id

    def agent(
        self,
        name: str,
        description: str | None = None,
        framework: str | None = None,
        llms: list[str] | None = None,
        purpose: str | None = None,
        repo_url: str | None = None,
        tags: list[str] | None = None,
        environment: str | None = None,
        **kwargs: Any,
    ) -> AgentHandle:
        """Returns an AgentHandle for a named agent hosted within this process.

        Multiple calls with the same agent name in the same process return the same handle (idempotent).
        All agents in the process share one background heartbeat thread and one process instance_id.
        """
        with self._lock:
            if name in self._agent_handles:
                handle = self._agent_handles[name]
                if description is not None:
                    handle.description = description
                if framework is not None:
                    handle.framework = framework
                if llms is not None:
                    handle.llms = llms
                return handle

            handle = AgentHandle(
                tower=self,
                name=name,
                description=description,
                framework=framework,
                llms=llms,
                purpose=purpose,
                repo_url=repo_url,
                tags=tags,
                environment=environment,
                **kwargs,
            )
            self._agent_handles[name] = handle
            return handle

    def register_all(
        self,
        agents: list[AgentHandle | dict[str, Any] | str],
    ) -> list[str | None]:
        """Convenience helper to register multiple agents in this process in one call.

        Each agent registration is isolated: one agent failing to register will not prevent
        other agents from registering. No exceptions propagate to the host application (unless strict=True).
        """
        results: list[str | None] = []
        for item in agents:
            try:
                if isinstance(item, AgentHandle):
                    handle = item
                elif isinstance(item, dict):
                    handle = self.agent(**item)
                elif isinstance(item, str):
                    handle = self.agent(name=item)
                else:
                    continue
                aid = handle.register()
                results.append(aid)
            except Exception as exc:
                self._handle_error(f"Failed to register agent from '{item}': {exc}", exc)
                results.append(None)
        return results

    def start(self) -> "ControlTower":
        """Starts the background heartbeat thread (in server mode). Non-blocking."""
        if self.disabled or self.mode == "serverless" or self._is_started:
            return self

        # Check for fork: if PID changed, generate a new instance_id and reset thread
        if os.getpid() != self._created_pid:
            self._created_pid = os.getpid()
            self.instance_id = self._generate_instance_id()
            self._thread = None

        self._stop_event.clear()
        self._thread = threading.Thread(
            target=self._background_loop,
            name="control-tower-heartbeat",
            daemon=True,
        )
        self._thread.start()
        self._is_started = True
        logger.debug("Control Tower heartbeat thread started (interval=%ds)", self.heartbeat_seconds)
        return self

    def stop(self, timeout: float = 2.0) -> None:
        """Stops the background heartbeat worker thread gracefully."""
        if not self._is_started or not self._thread:
            return
        self._stop_event.set()
        self._thread.join(timeout=timeout)
        self._is_started = False
        self._thread = None
        logger.debug("Control Tower heartbeat thread stopped")

    def heartbeat_once(
        self,
        metrics: dict[str, Any] | None = None,
        status: str | None = None,
        uptime: float | None = None,
    ) -> dict[str, Any] | None:
        """Synchronously transmits an immediate heartbeat. Ideal for serverless jobs."""
        if self.disabled:
            return {"status": "ok", "disabled": True}

        # Check fork safety
        if os.getpid() != self._created_pid:
            self._created_pid = os.getpid()
            self.instance_id = self._generate_instance_id()

        payload = {
            "agent_id": self.agent_id,
            "fingerprint": self.fingerprint,
            "instance_id": self.instance_id,
            "sdk_version": "0.2.0",
            "status": status or "active",
            "metrics": metrics or {},
            "uptime": uptime,
        }

        try:
            return self._post("/api/v1/sdk/heartbeat", payload)
        except Exception as exc:
            self._handle_error(f"Heartbeat transmission failed: {exc}", exc)
            return None

    def flush(self, timeout: float = 2.0) -> None:
        """Flushes buffered LLM events and sends an immediate heartbeat."""
        if self.disabled:
            return
        self.flush_events()
        if self.agent_id or self.fingerprint:
            self.heartbeat_once()

    def track_llm_call(
        self,
        provider: str,
        model: str,
        input_tokens: int = 0,
        output_tokens: int = 0,
        latency_ms: float = 0.0,
        status: str = "success",
        error_message: str | None = None,
        agent_id: str | None = None,
    ) -> None:
        """Records an opt-in LLM call event (model, tokens, latency, status).

        Content capture is OFF by default and cannot be enabled silently.
        """
        if self.disabled:
            return

        target_agent_id = agent_id or self.agent_id
        event = {
            "agent_id": target_agent_id,
            "instance_id": self.instance_id,
            "provider": str(provider),
            "model": str(model),
            "input_tokens": max(0, int(input_tokens)),
            "output_tokens": max(0, int(output_tokens)),
            "total_tokens": max(0, int(input_tokens)) + max(0, int(output_tokens)),
            "latency_ms": max(0.0, float(latency_ms)),
            "status": "error" if str(status).lower() in ("error", "failed") else "success",
            "error_message": str(error_message)[:500] if error_message else None,
        }
        with self._events_lock:
            self._events_queue.append(event)

        if self.mode == "serverless":
            self.flush_events()

    def flush_events(self, batch_size: int = 100) -> int:
        """Flushes buffered LLM call events to the Control Tower."""
        if self.disabled:
            return 0

        batch: list[dict[str, Any]] = []
        with self._events_lock:
            while self._events_queue and len(batch) < batch_size:
                batch.append(self._events_queue.popleft())

        if not batch:
            return 0

        try:
            payload = {
                "agent_id": self.agent_id,
                "instance_id": self.instance_id,
                "events": batch,
            }
            res = self._post("/api/v1/sdk/events", payload)
            return res.get("ingested_count", len(batch)) if res else 0
        except Exception as exc:
            # Re-queue on failure
            with self._events_lock:
                for ev in reversed(batch):
                    self._events_queue.appendleft(ev)
            self._handle_error(f"Failed to flush LLM events: {exc}", exc)
            return 0

    def wrap_openai(self, client: Any) -> Any:
        """Instruments an OpenAI client instance to record model, token counts, latency, and errors.

        Content capture is strictly OFF by default and cannot be enabled silently.
        """
        try:
            original_create = client.chat.completions.create

            def tracked_create(*args: Any, **kwargs: Any) -> Any:
                model_name = kwargs.get("model", "unknown")
                t0 = time.perf_counter()
                try:
                    resp = original_create(*args, **kwargs)
                    latency = (time.perf_counter() - t0) * 1000.0
                    usage = getattr(resp, "usage", None)
                    in_tok = getattr(usage, "prompt_tokens", 0) if usage else 0
                    out_tok = getattr(usage, "completion_tokens", 0) if usage else 0
                    actual_model = getattr(resp, "model", None) or model_name
                    self.track_llm_call(
                        provider="openai",
                        model=actual_model,
                        input_tokens=in_tok or 0,
                        output_tokens=out_tok or 0,
                        latency_ms=latency,
                        status="success",
                    )
                    return resp
                except Exception as exc:
                    latency = (time.perf_counter() - t0) * 1000.0
                    self.track_llm_call(
                        provider="openai",
                        model=model_name,
                        latency_ms=latency,
                        status="error",
                        error_message=str(exc),
                    )
                    raise

            client.chat.completions.create = tracked_create
        except Exception as exc:
            self._handle_error(f"Failed to wrap OpenAI client: {exc}", exc)
        return client

    def wrap_anthropic(self, client: Any) -> Any:
        """Instruments an Anthropic client instance to record model, token counts, latency, and errors.

        Content capture is strictly OFF by default and cannot be enabled silently.
        """
        try:
            original_create = client.messages.create

            def tracked_create(*args: Any, **kwargs: Any) -> Any:
                model_name = kwargs.get("model", "unknown")
                t0 = time.perf_counter()
                try:
                    resp = original_create(*args, **kwargs)
                    latency = (time.perf_counter() - t0) * 1000.0
                    usage = getattr(resp, "usage", None)
                    in_tok = getattr(usage, "input_tokens", 0) if usage else 0
                    out_tok = getattr(usage, "output_tokens", 0) if usage else 0
                    actual_model = getattr(resp, "model", None) or model_name
                    self.track_llm_call(
                        provider="anthropic",
                        model=actual_model,
                        input_tokens=in_tok or 0,
                        output_tokens=out_tok or 0,
                        latency_ms=latency,
                        status="success",
                    )
                    return resp
                except Exception as exc:
                    latency = (time.perf_counter() - t0) * 1000.0
                    self.track_llm_call(
                        provider="anthropic",
                        model=model_name,
                        latency_ms=latency,
                        status="error",
                        error_message=str(exc),
                    )
                    raise

            client.messages.create = tracked_create
        except Exception as exc:
            self._handle_error(f"Failed to wrap Anthropic client: {exc}", exc)
        return client

    # -------------------------------------------------------------------------
    # Context Manager & Backwards-Compatible Helpers
    # -------------------------------------------------------------------------

    def __enter__(self) -> "ControlTower":
        if not self.agent_id:
            self.register()
        self.start()
        return self

    def __exit__(self, exc_type: object, exc_val: object, exc_tb: object) -> None:
        self.stop()
        self.flush()

    def register_agent(self, **kwargs: Any) -> dict[str, Any]:
        """Backwards-compatible registration helper returning the raw dictionary."""
        name = kwargs.get("name") or self.agent_name
        self.agent_name = name
        agent_id = self.register(
            description=kwargs.get("description"),
            purpose=kwargs.get("purpose"),
            framework=kwargs.get("framework"),
            llms=kwargs.get("llm_models") or kwargs.get("llms"),
            repo_url=kwargs.get("repo_url"),
            tags=kwargs.get("tags"),
        )
        return {
            "agent_id": agent_id or f"agent-fallback-{uuid.uuid4().hex[:8]}",
            "name": self.agent_name,
            "status": "active",
            "risk_tier": "Unassessed",
        }

    def heartbeat(
        self,
        agent_id: str | None = None,
        metrics: dict[str, Any] | None = None,
        status: str | None = None,
    ) -> dict[str, Any]:
        """Backwards-compatible heartbeat method."""
        if agent_id:
            self.agent_id = agent_id
        payload = {
            "agent_id": self.agent_id,
            "fingerprint": self.fingerprint,
            "instance_id": self.instance_id,
            "sdk_version": "0.2.0",
            "status": status or "active",
            "metrics": metrics or {},
        }
        return self._post("/api/v1/sdk/heartbeat", payload)

    @contextmanager
    def agent_session(
        self,
        name: str,
        framework: str = "custom",
        environment: str = "Production",
        llm_models: list[str] | None = None,
        **kwargs: Any,
    ) -> Generator[AgentSession, None, None]:
        """Context manager for scoped agent sessions."""
        data = self.register_agent(
            name=name,
            framework=framework,
            environment=environment,
            llm_models=llm_models,
            **kwargs,
        )
        session = AgentSession(self, data)
        try:
            yield session
        finally:
            if session.agent_id:
                try:
                    self.heartbeat(session.agent_id)
                except Exception:
                    pass

    def track_agent(
        self,
        name: str,
        framework: str = "custom",
        environment: str = "Production",
        llm_models: list[str] | None = None,
        **register_kwargs: Any,
    ) -> Callable:
        """Decorator for autonomous functions to self-register and emit heartbeats."""
        def decorator(func: Callable) -> Callable:
            @functools.wraps(func)
            def wrapper(*args: Any, **kwargs: Any) -> Any:
                with self.agent_session(
                    name=name,
                    framework=framework,
                    environment=environment,
                    llm_models=llm_models,
                    **register_kwargs,
                ):
                    return func(*args, **kwargs)
            return wrapper
        return decorator

    # -------------------------------------------------------------------------
    # Internal Engine & Safe Network I/O
    # -------------------------------------------------------------------------

    def _validate_url_security(self) -> None:
        """Validates HTTPS requirement. Refuses HTTP unless localhost or allow_insecure=True."""
        if self.disabled:
            return
        parsed = urllib.parse.urlparse(self.url)
        host = (parsed.hostname or "").lower()
        is_local = host in ("localhost", "127.0.0.1", "0.0.0.0", "::1", "")

        if parsed.scheme == "http" and not is_local:
            msg = (
                f"Insecure HTTP URL '{self.url}' disallowed for remote AI Control Tower. "
                f"Require HTTPS in production, or pass allow_insecure=True with loud warning."
            )
            if not self.config.allow_insecure:
                if self.strict:
                    raise ControlTowerError(msg)
                logger.error("SECURITY WARNING: %s (disabling telemetry)", msg)
                self.disabled = True
            else:
                logger.warning("SECURITY WARNING: Using insecure HTTP connection to remote host %s", host)

    def _resolve_mode(self, configured_mode: str) -> str:
        """Resolves 'auto' mode into 'serverless' or 'server'."""
        if configured_mode in ("server", "serverless"):
            return configured_mode
        env = os.environ
        if any(k in env for k in ("AWS_LAMBDA_FUNCTION_NAME", "FUNCTIONS_WORKER_RUNTIME", "K_SERVICE", "GAE_SERVICE")):
            return "serverless"
        cloud_platform = (self._detected_env or {}).get("cloud", {}).get("platform", "")
        if any(kw in cloud_platform.lower() for kw in ("lambda", "function", "cloud run", "app engine")):
            return "serverless"
        return "server"

    def _generate_instance_id(self) -> str:
        """Generates a per-process instance identifier (safe for multi-worker uvicorn/gunicorn)."""
        host = socket.gethostname().split(".")[0]
        pid = os.getpid()
        rnd = uuid.uuid4().hex[:6]
        return f"{host}-{pid}-{rnd}"

    def _post(self, endpoint: str, data: dict[str, Any], timeout: float = 5.0) -> dict[str, Any]:
        """Low-level HTTP POST using urllib with timeout, header auth, and error parsing."""
        url = f"{self.url}{endpoint}"
        payload = json.dumps(data).encode("utf-8")
        req = urllib.request.Request(
            url,
            data=payload,
            headers={
                "Content-Type": "application/json",
                "X-API-Key": self.api_key,
                "User-Agent": "control-tower-sdk-python/0.2.0",
            },
            method="POST",
        )

        try:
            with urllib.request.urlopen(req, timeout=timeout) as response:
                resp_bytes = response.read()
                return json.loads(resp_bytes.decode("utf-8"))
        except urllib.error.HTTPError as exc:
            err_body = exc.read().decode("utf-8", errors="replace")
            # Clear actionable error messages
            if exc.code == 401:
                action = "API key is invalid or revoked. Check Settings > API Keys in AI Control Tower."
            elif exc.code == 403:
                action = "API key lacks required scope (e.g. sdk:register or sdk:heartbeat)."
            elif exc.code == 429:
                action = "Rate limit exceeded (maximum requests reached). Backing off."
            else:
                action = f"Server returned error HTTP {exc.code}."

            logger.error("Control Tower API error (%d): %s | %s", exc.code, action, err_body)
            raise ControlTowerError(
                f"HTTP {exc.code}: {action}",
                status_code=exc.code,
                response_body=err_body,
            ) from exc
        except urllib.error.URLError as exc:
            reason = str(exc.reason)
            if "Name or service not known" in reason or "getaddrinfo failed" in reason:
                logger.error("DNS lookup failed for %s: is the Control Tower URL public and reachable?", self.url)
            elif "Connection refused" in reason:
                logger.error("Connection refused at %s: is the Control Tower service running?", self.url)
            else:
                logger.error("Network error contacting Control Tower: %s", reason)
            raise ControlTowerError(f"Connection failed: {reason}") from exc

    def _register_agent_handle(
        self,
        handle: AgentHandle,
        description: str | None = None,
        purpose: str | None = None,
        framework: str | None = None,
        llms: list[str] | None = None,
        repo_url: str | None = None,
        tags: list[str] | None = None,
        **kwargs: Any,
    ) -> str | None:
        """Internal helper to register an AgentHandle idempotently."""
        if self.disabled:
            handle.agent_id = handle.agent_id or f"disabled-{handle.name}"
            return handle.agent_id

        if self._detected_env is None:
            self._detected_env = detect(redact=True, probe_imds=bool(self.config.probe_imds))

        payload = {
            "name": handle.name,
            "agent_name": handle.name,
            "environment": handle.environment or self.environment,
            "description": description or handle.description or f"Agent self-registered from {self._detected_env.get('cloud', {}).get('platform', 'host')}.",
            "purpose": purpose or handle.purpose or "",
            "framework": framework or handle.framework or self._detected_env.get("application", {}).get("framework", "custom"),
            "llms": llms or handle.llms or kwargs.get("llm_models") or [],
            "repo_url": repo_url or handle.repo_url or self._detected_env.get("git", {}).get("repo_url"),
            "tags": tags or handle.tags or [],
            "instance_id": self.instance_id,
            "sdk_version": "0.2.0",
            "fingerprint": handle.fingerprint,
            "environment_details": self._detected_env,
        }

        try:
            resp = self._post("/api/v1/sdk/register", payload)
            handle.agent_id = resp.get("agent_id")
            if resp.get("fingerprint"):
                handle.fingerprint = resp.get("fingerprint")
            logger.info("Agent handle '%s' registered successfully (id=%s)", handle.name, handle.agent_id)
            return handle.agent_id
        except Exception as exc:
            self._handle_error(f"Failed to register agent '{handle.name}': {exc}", exc)
            return handle.agent_id

    def _heartbeat_agent_handle(
        self,
        handle: AgentHandle,
        metrics: dict[str, Any] | None = None,
        status: str | None = None,
        uptime: float | None = None,
    ) -> dict[str, Any] | None:
        """Internal helper to emit a heartbeat for an AgentHandle."""
        if self.disabled:
            return {"status": "ok", "disabled": True}

        if not handle.agent_id and not handle.fingerprint:
            return None

        # Check fork safety
        if os.getpid() != self._created_pid:
            self._created_pid = os.getpid()
            self.instance_id = self._generate_instance_id()

        payload = {
            "agent_id": handle.agent_id,
            "fingerprint": handle.fingerprint,
            "instance_id": self.instance_id,
            "sdk_version": "0.2.0",
            "status": status or "active",
            "metrics": metrics or {},
            "uptime": uptime,
        }

        try:
            return self._post("/api/v1/sdk/heartbeat", payload)
        except Exception as exc:
            self._handle_error(f"Heartbeat transmission failed for agent '{handle.name}': {exc}", exc)
            return None

    def _background_loop(self) -> None:
        """Background thread executing periodic heartbeats with jitter and backoff.

        Single shared heartbeat thread across all agents hosted in this process.
        Sends one heartbeat per registered agent each interval.
        """
        # Initial registration attempt for main agent if configured and not using handles
        if not self.agent_id and not self._agent_handles:
            try:
                self.register()
            except Exception:
                pass

        # Initial registration attempt for any pending handles
        with self._lock:
            initial_handles = list(self._agent_handles.values())
        for h in initial_handles:
            if not h.agent_id:
                try:
                    h.register()
                except Exception:
                    pass

        backoff = 2.0
        while not self._stop_event.is_set():
            # Apply +/- 10% jitter to heartbeat interval
            jitter = random.uniform(-0.1, 0.1) * self.heartbeat_seconds
            interval = max(5.0, self.heartbeat_seconds + jitter)

            # Wait for next heartbeat or stop event
            if self._stop_event.wait(timeout=interval):
                break

            # Flush buffered events along with periodic heartbeat
            self.flush_events()

            # Heartbeat main agent if registered
            if self.agent_id and self.agent_name not in self._agent_handles:
                try:
                    res = self.heartbeat_once()
                    if res and res.get("status") == "ok":
                        backoff = 2.0
                    else:
                        backoff = min(60.0, backoff * 1.5)
                except Exception:
                    backoff = min(60.0, backoff * 1.5)

            # Heartbeat each registered agent handle
            with self._lock:
                current_handles = list(self._agent_handles.values())
            for h in current_handles:
                if not h.agent_id:
                    try:
                        h.register()
                    except Exception:
                        pass
                if h.agent_id:
                    try:
                        res = h.heartbeat_once()
                        if res and res.get("status") == "ok":
                            backoff = 2.0
                    except Exception:
                        pass

    def _handle_error(self, message: str, exc: Exception) -> None:
        """Logs error; raises if strict=True, swallows otherwise to protect host app."""
        logger.warning(message)
        if self.strict:
            raise exc

    def _atexit_handler(self) -> None:
        """Best-effort flush on process exit."""
        try:
            if not self.disabled:
                self.flush_events()
                if self.agent_id and self.agent_name not in self._agent_handles:
                    # Fast timeout (1s) on process exit
                    self._post(
                        "/api/v1/sdk/heartbeat",
                        {
                            "agent_id": self.agent_id,
                            "instance_id": self.instance_id,
                            "status": "stopped",
                        },
                        timeout=1.0,
                    )
                with self._lock:
                    handles = list(self._agent_handles.values())
                for h in handles:
                    if h.agent_id:
                        self._post(
                            "/api/v1/sdk/heartbeat",
                            {
                                "agent_id": h.agent_id,
                                "instance_id": self.instance_id,
                                "status": "stopped",
                            },
                            timeout=1.0,
                        )
        except Exception:
            pass


_default_client: ControlTower | None = None


def init(
    url: str | None = None,
    api_key: str | None = None,
    agent_name: str | None = None,
    environment: str | None = None,
    mode: str = "auto",
    disabled: bool = False,
    **kwargs: Any,
) -> ControlTower:
    """One-line helper to configure, register, and start AI Control Tower monitoring.

    Safe and non-blocking: returns in under 100ms.
    """
    global _default_client
    ct = ControlTower(
        url=url,
        api_key=api_key,
        agent_name=agent_name,
        environment=environment,
        mode=mode,
        disabled=disabled,
        **kwargs,
    )
    # Start thread immediately; registration runs in background or synchronously if desired
    ct.start()
    _default_client = ct
    return ct


def track_llm_call(*args: Any, **kwargs: Any) -> None:
    """Module-level helper to track an LLM call on the active default ControlTower instance."""
    if _default_client:
        _default_client.track_llm_call(*args, **kwargs)


def wrap_openai(client: Any) -> Any:
    """Module-level helper to instrument an OpenAI client on the active default ControlTower instance."""
    if _default_client:
        return _default_client.wrap_openai(client)
    return client


def wrap_anthropic(client: Any) -> Any:
    """Module-level helper to instrument an Anthropic client on the active default ControlTower instance."""
    if _default_client:
        return _default_client.wrap_anthropic(client)
    return client
