"""Official AI Control Tower Python SDK.

Zero required third-party dependencies: strictly uses Python standard library.
Enables autonomous AI agents running in ANY cloud (Azure, AWS, GCP, K8s, VMs, Serverless, Local)
to self-register, report environment details, and emit heartbeat telemetry.
"""
from control_tower_sdk.client import (
    AgentHandle,
    AgentSession,
    ControlTower,
    ControlTowerError,
    init,
    track_llm_call,
    wrap_anthropic,
    wrap_openai,
)
from control_tower_sdk.config import SdkConfig
from control_tower_sdk.detect import detect

__all__ = [
    "AgentHandle",
    "AgentSession",
    "ControlTower",
    "ControlTowerError",
    "SdkConfig",
    "detect",
    "init",
    "track_llm_call",
    "wrap_anthropic",
    "wrap_openai",
]
__version__ = "0.2.0"
