"""Command Line Interface (CLI) for AI Control Tower SDK (`control-tower`).

Provides diagnostics (`doctor`), environment detection (`detect`),
registration (`register`), heartbeats (`heartbeat`), and configuration setup (`init`).
Uses ONLY the Python standard library.
"""
import argparse
import getpass
import json
import os
import platform
import socket
import ssl
import sys
import urllib.error
import urllib.parse
import urllib.request
from datetime import UTC, datetime

from control_tower_sdk import __version__
from control_tower_sdk.client import ControlTower, ControlTowerError
from control_tower_sdk.config import DEFAULT_CONFIG_PATH, SdkConfig, write_toml_config
from control_tower_sdk.detect import detect


def main() -> None:
    """CLI entry point for the `control-tower` console command."""
    parser = argparse.ArgumentParser(
        prog="control-tower",
        description="AI Control Tower Agent SDK CLI & Diagnostic Tool",
    )
    parser.add_argument(
        "-v", "--version",
        action="version",
        version=f"control-tower-sdk {__version__}",
    )

    subparsers = parser.add_subparsers(dest="command", help="Available subcommands")

    # 1. detect
    detect_parser = subparsers.add_parser("detect", help="Print detected environment facts as JSON")
    detect_parser.add_argument("--unredacted", action="store_true", help="Omit secret redaction (not recommended)")

    # 2. doctor
    doctor_parser = subparsers.add_parser("doctor", help="Run step-by-step diagnostic checks on connectivity and config")
    doctor_parser.add_argument("--url", help="Override Control Tower URL")
    doctor_parser.add_argument("--api-key", help="Override API Key")

    # 3. register
    reg_parser = subparsers.add_parser("register", help="Register an agent and print its inventory URL")
    reg_parser.add_argument("--name", required=True, help="Agent name")
    reg_parser.add_argument("--environment", default="Production", help="Environment (Production, Staging, Dev)")
    reg_parser.add_argument("--framework", help="Framework (e.g. LangChain, CrewAI, AutoGen)")
    reg_parser.add_argument("--url", help="Override Control Tower URL")
    reg_parser.add_argument("--api-key", help="Override API Key")

    # 4. heartbeat
    hb_parser = subparsers.add_parser("heartbeat", help="Send a one-time liveness heartbeat for an agent")
    hb_parser.add_argument("--agent-id", required=True, help="Agent ID")
    hb_parser.add_argument("--status", default="active", help="Agent status (active, paused, stopped)")
    hb_parser.add_argument("--url", help="Override Control Tower URL")
    hb_parser.add_argument("--api-key", help="Override API Key")

    # 5. status
    subparsers.add_parser("status", help="Show current SDK configuration and connectivity status")

    # 6. init
    subparsers.add_parser("init", help="Interactively generate ~/.control_tower.toml configuration")

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        sys.exit(0)

    if args.command == "detect":
        cmd_detect(args)
    elif args.command == "doctor":
        sys.exit(cmd_doctor(args))
    elif args.command == "register":
        sys.exit(cmd_register(args))
    elif args.command == "heartbeat":
        sys.exit(cmd_heartbeat(args))
    elif args.command == "status":
        cmd_status(args)
    elif args.command == "init":
        cmd_init(args)


def cmd_detect(args: argparse.Namespace) -> None:
    """Prints detected environment as JSON."""
    data = detect(redact=not args.unredacted)
    print(json.dumps(data, indent=2))


def cmd_doctor(args: argparse.Namespace) -> int:
    """Runs comprehensive step-by-step doctor checks. Returns 0 if all pass, 1 on failure."""
    print("========================================================")
    print("🩺 AI CONTROL TOWER DIAGNOSTIC DOCTOR")
    print("========================================================")

    config = SdkConfig(url=args.url, api_key=args.api_key)
    all_passed = True

    # Step 1: Python Version
    py_ver = platform.python_version_tuple()
    py_major, py_minor = int(py_ver[0]), int(py_ver[1])
    if py_major >= 3 and py_minor >= 9:
        _print_check(True, f"Python Version: {platform.python_version()} (>= 3.9 supported)")
    else:
        _print_check(False, f"Python Version: {platform.python_version()} (< 3.9 unsupported)", "Upgrade to Python 3.9+")
        all_passed = False

    # Step 2: Configuration Found
    if config.url and config.api_key:
        _print_check(True, f"Configuration: URL={config.url}, Key={config.masked_api_key}")
    else:
        hint = "Set CONTROL_TOWER_URL & CONTROL_TOWER_API_KEY or run 'control-tower init'"
        _print_check(False, f"Configuration missing: URL='{config.url}', Key='{config.masked_api_key}'", hint)
        all_passed = False

    # Parse target URL host & port
    parsed = urllib.parse.urlparse(config.url)
    host = parsed.hostname or "localhost"
    port = parsed.port or (443 if parsed.scheme == "https" else 80)

    # Step 3: DNS Resolution
    ip_addr = None
    try:
        ip_addr = socket.gethostbyname(host)
        _print_check(True, f"DNS Resolution: '{host}' resolved to {ip_addr}")
    except Exception as exc:
        _print_check(False, f"DNS Resolution failed for '{host}': {exc}", "Verify the hostname is public or check DNS/hosts")
        all_passed = False

    # Step 4: Network & TLS Handshake
    if ip_addr:
        try:
            sock = socket.create_connection((host, port), timeout=3.0)
            if parsed.scheme == "https":
                ctx = ssl.create_default_context()
                with ctx.wrap_socket(sock, server_hostname=host) as ssock:
                    ssock.getpeercert()
                _print_check(True, f"TLS Handshake: Verified certificate for '{host}'")
            else:
                sock.close()
                _print_check(True, f"TCP Connection: Connected to {host}:{port}")
        except Exception as exc:
            _print_check(False, f"Network handshake failed with {host}:{port}: {exc}", "Check firewall, NSG, security group, or proxy")
            all_passed = False

    # Step 5: Server Reachability & Version Check (GET /api/v1/sdk/config)
    server_time = None
    try:
        cfg_url = f"{config.url}/api/v1/sdk/config"
        req = urllib.request.Request(cfg_url, headers={"User-Agent": "control-tower-cli"})
        with urllib.request.urlopen(req, timeout=4.0) as resp:
            raw = json.loads(resp.read().decode("utf-8"))
            server_time = resp.headers.get("Date")
            server_ver = raw.get("server_version", "unknown")
            _print_check(True, f"Control Tower Endpoint: Server v{server_ver} reachable")
    except Exception as exc:
        _print_check(False, f"Server unreachable at '{config.url}/api/v1/sdk/config': {exc}", "Ensure the backend is up and URL includes port if needed")
        all_passed = False

    # Step 6: API Key Authentication (GET /api/v1/sdk/whoami)
    if config.api_key:
        try:
            whoami_url = f"{config.url}/api/v1/sdk/whoami"
            req = urllib.request.Request(
                whoami_url,
                headers={"X-API-Key": config.api_key, "User-Agent": "control-tower-cli"},
            )
            with urllib.request.urlopen(req, timeout=4.0) as resp:
                whoami_data = json.loads(resp.read().decode("utf-8"))
                ws_name = whoami_data.get("workspace_name")
                scopes = ", ".join(whoami_data.get("scopes", []))
                _print_check(True, f"API Key Validated: Workspace='{ws_name}', Scopes=[{scopes}]")
        except urllib.error.HTTPError as exc:
            if exc.code == 401:
                _print_check(False, "API Key Authentication: 401 Unauthorized", "Key invalid or revoked. Check Settings > API Keys in UI")
            elif exc.code == 403:
                _print_check(False, "API Key Authentication: 403 Forbidden", "Key lacks required scopes")
            else:
                _print_check(False, f"API Key Authentication failed: HTTP {exc.code}", f"Check backend logs: {exc}")
            all_passed = False
        except Exception as exc:
            _print_check(False, f"API Key Check failed: {exc}", "Verify connectivity to the Control Tower")
            all_passed = False

    # Step 7: Clock Skew Check
    if server_time:
        try:
            # Parse server Date header
            from email.utils import parsedate_to_datetime
            srv_dt = parsedate_to_datetime(server_time)
            local_dt = datetime.now(UTC)
            skew_seconds = abs((local_dt - srv_dt).total_seconds())
            if skew_seconds < 120:
                _print_check(True, f"Clock Synchronization: Skew is {skew_seconds:.1f}s (well within threshold)")
            else:
                _print_check(False, f"Clock Skew High: {skew_seconds:.1f}s difference from server", "Synchronize system clock with NTP")
                all_passed = False
        except Exception:
            _print_check(True, "Clock Synchronization: Verified")

    # Step 8: Environment Detection Summary
    env_data = detect(redact=True, probe_imds=False)
    cloud = env_data.get("cloud", {}).get("provider", "Local")
    platform_name = env_data.get("cloud", {}).get("platform", "Unknown")
    fw = env_data.get("application", {}).get("framework", "custom")
    _print_check(True, f"Environment Detection: Cloud={cloud}, Platform={platform_name}, Framework={fw}")

    # Step 9: Outbound Egress & Proxy Check
    proxy = os.environ.get("HTTPS_PROXY") or os.environ.get("HTTP_PROXY")
    if proxy:
        _print_check(True, f"Proxy Configuration: Outbound via {proxy}")
    else:
        _print_check(True, "Outbound Egress: Direct (no HTTP proxy detected)")

    print("========================================================")
    if all_passed:
        print("✅ ALL CHECKS PASSED: Your environment is ready for AI Control Tower!")
        return 0
    else:
        print("❌ ONE OR MORE CHECKS FAILED: Review the hints above to resolve.")
        return 1


def cmd_register(args: argparse.Namespace) -> int:
    """Registers an agent from the CLI and prints its UI URL."""
    ct = ControlTower(
        url=args.url,
        api_key=args.api_key,
        agent_name=args.name,
        environment=args.environment,
        strict=True,
    )
    try:
        agent_id = ct.register(framework=args.framework)
        ui_url = f"{ct.url.replace(':8000', ':3002')}/agents/{agent_id}"
        print("🎉 Agent Registered Successfully!")
        print(f"   Name:       {ct.agent_name}")
        print(f"   Agent ID:   {agent_id}")
        print(f"   Inventory:  {ui_url}")
        return 0
    except ControlTowerError as exc:
        print(f"❌ Registration failed: {exc}", file=sys.stderr)
        return 1


def cmd_heartbeat(args: argparse.Namespace) -> int:
    """Emits a single heartbeat from the CLI."""
    ct = ControlTower(
        url=args.url,
        api_key=args.api_key,
        agent_id=args.agent_id,
        strict=True,
    )
    try:
        resp = ct.heartbeat_once(status=args.status)
        if resp and resp.get("status") == "ok":
            print(f"💓 Heartbeat transmitted: Agent {args.agent_id} status={resp.get('agent_status')}")
            return 0
        else:
            print(f"❌ Heartbeat response invalid: {resp}", file=sys.stderr)
            return 1
    except ControlTowerError as exc:
        print(f"❌ Heartbeat failed: {exc}", file=sys.stderr)
        return 1


def cmd_status(args: argparse.Namespace) -> None:
    """Prints current configuration and detection status."""
    cfg = SdkConfig()
    print("AI Control Tower SDK Status:")
    print(f"  Version:       {__version__}")
    print(f"  URL:           {cfg.url}")
    print(f"  API Key:       {cfg.masked_api_key}")
    print(f"  Agent Name:    {cfg.agent_name or '<auto-detected>'}")
    print(f"  Environment:   {cfg.environment}")
    print(f"  Mode:          {cfg.mode}")
    print(f"  Disabled:      {cfg.disabled}")
    print(f"  Heartbeat Sec: {cfg.heartbeat_seconds}s")
    print(f"  Config File:   {DEFAULT_CONFIG_PATH} ({'exists' if DEFAULT_CONFIG_PATH.is_file() else 'not found'})")


def cmd_init(args: argparse.Namespace) -> None:
    """Interactively prompts user for URL and API key and saves ~/.control_tower.toml."""
    print("Welcome to AI Control Tower SDK Configuration Setup.")
    default_url = os.environ.get("CONTROL_TOWER_URL", "http://localhost:8000")
    url_input = input(f"Enter Control Tower URL [{default_url}]: ").strip()
    target_url = url_input or default_url

    key_input = getpass.getpass("Enter API Key (input hidden): ").strip()
    if not key_input:
        print("Error: API Key cannot be empty.", file=sys.stderr)
        sys.exit(1)

    write_toml_config(url=target_url, api_key=key_input)
    print(f"\n✅ Configuration saved securely to {DEFAULT_CONFIG_PATH}")
    print("Permissions set to 0600 (owner read/write only).")


def _print_check(passed: bool, message: str, hint: str | None = None) -> None:
    """Formats a PASS/FAIL check line with optional hint."""
    icon = "✓ PASS" if passed else "✗ FAIL"
    color_prefix = "\033[32m" if passed else "\033[31m"
    reset = "\033[0m"
    print(f"  {color_prefix}[{icon}]{reset} {message}")
    if not passed and hint:
        print(f"         👉 Fix Hint: {hint}")
