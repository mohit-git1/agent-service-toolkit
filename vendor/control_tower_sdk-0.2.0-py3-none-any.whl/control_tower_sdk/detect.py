"""Environment auto-detection module for AI Control Tower SDK.

Collects platform, cloud provider, host runtime, installed AI libraries,
and git metadata using ONLY the Python standard library.
Never raises exceptions; all probes use short timeouts (<=1s).
Never captures secret values.
"""
import importlib.metadata
import importlib.util
import json
import logging
import os
import platform
import re
import socket
import sys
import urllib.error
import urllib.request
from typing import Any

logger = logging.getLogger("control_tower_sdk.detect")

# Sensitive key patterns that must be redacted if they ever appear
SECRET_KEY_PATTERN = re.compile(
    r"(api_?key|token|secret|password|auth|bearer|credential|cert|private)",
    re.IGNORECASE,
)

# Common AI library packages to inspect via importlib.metadata
KNOWN_AI_LIBRARIES = [
    "openai",
    "anthropic",
    "google-generativeai",
    "google-cloud-aiplatform",
    "azure-ai-inference",
    "azure-ai-openai",
    "langchain",
    "langchain-core",
    "langgraph",
    "llama-index",
    "crewai",
    "autogen",
    "semantic-kernel",
    "transformers",
    "torch",
    "ollama",
    "cohere",
    "mistralai",
    "groq",
    "boto3",
]


def detect(
    redact: bool = True,
    probe_imds: bool = True,
    imds_timeout: float = 0.5,
) -> dict[str, Any]:
    """Auto-detects the running environment, cloud provider, and application metadata.

    Safe and non-raising: errors during any probe are caught and omitted.
    """
    data: dict[str, Any] = {
        "cloud": _detect_cloud(probe_imds=probe_imds, timeout=imds_timeout),
        "runtime": _detect_runtime(),
        "application": _detect_application(),
        "llm_providers": _detect_llm_provider_hints(),
        "git": _detect_git_info(),
    }

    if redact:
        data = redact_secrets(data)

    return data


def _detect_cloud(probe_imds: bool = True, timeout: float = 0.5) -> dict[str, Any]:
    """Detects cloud provider (Azure, AWS, GCP, K8s, PaaS, or VM IMDS)."""
    # 1. Environment variable based checks (instant, zero network)
    env = os.environ

    # Azure App Service
    if "WEBSITE_SITE_NAME" in env:
        return {
            "provider": "Azure",
            "platform": "Azure App Service",
            "resource_name": env.get("WEBSITE_SITE_NAME"),
            "resource_group": env.get("WEBSITE_RESOURCE_GROUP"),
            "region": env.get("REGION_NAME"),
            "owner": env.get("WEBSITE_OWNER_NAME"),
            "instance_id": env.get("WEBSITE_INSTANCE_ID"),
        }

    # Azure Container Apps
    if "CONTAINER_APP_NAME" in env:
        return {
            "provider": "Azure",
            "platform": "Azure Container Apps",
            "resource_name": env.get("CONTAINER_APP_NAME"),
            "replica": env.get("CONTAINER_APP_REPLICA_NAME"),
            "revision": env.get("CONTAINER_APP_REVISION"),
            "region": env.get("CONTAINER_APP_REGION") or env.get("REGION_NAME"),
        }

    # Azure Functions
    if "FUNCTIONS_WORKER_RUNTIME" in env:
        return {
            "provider": "Azure",
            "platform": "Azure Functions",
            "resource_name": env.get("WEBSITE_SITE_NAME") or env.get("AZURE_FUNCTIONS_ENVIRONMENT"),
            "region": env.get("REGION_NAME"),
            "worker_runtime": env.get("FUNCTIONS_WORKER_RUNTIME"),
        }

    # AWS Lambda
    if "AWS_LAMBDA_FUNCTION_NAME" in env:
        return {
            "provider": "AWS",
            "platform": "AWS Lambda",
            "resource_name": env.get("AWS_LAMBDA_FUNCTION_NAME"),
            "region": env.get("AWS_REGION") or env.get("AWS_DEFAULT_REGION"),
            "version": env.get("AWS_LAMBDA_FUNCTION_VERSION"),
            "memory_limit": env.get("AWS_LAMBDA_FUNCTION_MEMORY_SIZE"),
        }

    # AWS ECS
    if "ECS_CONTAINER_METADATA_URI_V4" in env or "ECS_CONTAINER_METADATA_URI" in env:
        return {
            "provider": "AWS",
            "platform": "AWS ECS",
            "region": env.get("AWS_REGION") or env.get("AWS_DEFAULT_REGION"),
            "task_arn": env.get("ECS_TASK_ARN"),
        }

    # AWS Elastic Beanstalk
    if "ELASTIC_BEANSTALK_ENVIRONMENT_NAME" in env or "AWS_EB_ENVIRONMENT_ID" in env:
        return {
            "provider": "AWS",
            "platform": "AWS Elastic Beanstalk",
            "environment_name": env.get("ELASTIC_BEANSTALK_ENVIRONMENT_NAME"),
            "region": env.get("AWS_REGION"),
        }

    # GCP Cloud Run
    if "K_SERVICE" in env:
        return {
            "provider": "GCP",
            "platform": "Cloud Run",
            "service": env.get("K_SERVICE"),
            "revision": env.get("K_REVISION"),
            "configuration": env.get("K_CONFIGURATION"),
            "region": env.get("CLOUD_RUN_REGION") or env.get("REGION"),
        }

    # GCP App Engine
    if "GAE_SERVICE" in env:
        return {
            "provider": "GCP",
            "platform": "App Engine",
            "service": env.get("GAE_SERVICE"),
            "instance": env.get("GAE_INSTANCE"),
            "runtime": env.get("GAE_ENV"),
        }

    # Kubernetes (any cloud)
    if "KUBERNETES_SERVICE_HOST" in env:
        return {
            "provider": "Kubernetes",
            "platform": "Kubernetes Pod",
            "host": env.get("KUBERNETES_SERVICE_HOST"),
            "pod_name": env.get("HOSTNAME"),
            "namespace": env.get("POD_NAMESPACE"),
        }

    # PaaS platforms
    if "DYNO" in env:
        return {"provider": "Heroku", "platform": "Heroku Dyno", "dyno": env.get("DYNO")}
    if "RENDER" in env:
        return {
            "provider": "Render",
            "platform": "render",
            "service_name": env.get("RENDER_SERVICE_NAME"),
            "public_url": env.get("RENDER_EXTERNAL_URL"),
            "git_commit": env.get("RENDER_GIT_COMMIT"),
            "git_repo_slug": env.get("RENDER_GIT_REPO_SLUG"),
            "instance_id": env.get("RENDER_INSTANCE_ID"),
            "service_id": env.get("RENDER_SERVICE_ID"),
            "service_type": env.get("RENDER_SERVICE_TYPE"),
        }
    if "RAILWAY_ENVIRONMENT" in env:
        return {"provider": "Railway", "platform": "Railway Container", "environment": env.get("RAILWAY_ENVIRONMENT")}
    if "FLY_APP_NAME" in env:
        return {"provider": "Fly.io", "platform": "Fly Machine", "app_name": env.get("FLY_APP_NAME"), "region": env.get("FLY_REGION")}

    # 2. Instance Metadata Service (IMDS) for VMs (only if enabled)
    if probe_imds:
        # Probe Azure IMDS
        azure_imds = probe_azure_imds(timeout=timeout)
        if azure_imds:
            return azure_imds

        # Probe AWS IMDSv2
        aws_imds = probe_aws_imds(timeout=timeout)
        if aws_imds:
            return aws_imds

        # Probe GCP IMDS
        gcp_imds = probe_gcp_imds(timeout=timeout)
        if gcp_imds:
            return gcp_imds

    return {"provider": "Local", "platform": "Bare Metal / VM"}


def probe_azure_imds(timeout: float = 0.5) -> dict[str, Any] | None:
    """Probes Azure Instance Metadata Service (IMDS)."""
    url = "http://169.254.169.254/metadata/instance?api-version=2021-02-01"
    req = urllib.request.Request(url, headers={"Metadata": "true"})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            data = json.loads(resp.read().decode("utf-8"))
            compute = data.get("compute", {})
            return {
                "provider": "Azure",
                "platform": "Azure Virtual Machine",
                "region": compute.get("location"),
                "subscription_id": compute.get("subscriptionId"),
                "resource_group": compute.get("resourceGroupName"),
                "instance_id": compute.get("vmId"),
                "instance_name": compute.get("name"),
                "instance_type": compute.get("vmSize"),
                "resource_id": compute.get("resourceId"),
            }
    except Exception:
        return None


def probe_aws_imds(timeout: float = 0.5) -> dict[str, Any] | None:
    """Probes AWS IMDSv2 (Token-based instance identity document)."""
    token_url = "http://169.254.169.254/latest/api/token"
    token_req = urllib.request.Request(
        token_url,
        headers={"X-aws-ec2-metadata-token-ttl-seconds": "60"},
        method="PUT",
    )
    try:
        with urllib.request.urlopen(token_req, timeout=timeout) as token_resp:
            token = token_resp.read().decode("utf-8").strip()

        doc_url = "http://169.254.169.254/latest/dynamic/instance-identity/document"
        doc_req = urllib.request.Request(doc_url, headers={"X-aws-ec2-metadata-token": token})
        with urllib.request.urlopen(doc_req, timeout=timeout) as doc_resp:
            doc = json.loads(doc_resp.read().decode("utf-8"))
            return {
                "provider": "AWS",
                "platform": "AWS EC2",
                "region": doc.get("region"),
                "account_id": doc.get("accountId"),
                "instance_id": doc.get("instanceId"),
                "instance_type": doc.get("instanceType"),
                "availability_zone": doc.get("availabilityZone"),
                "image_id": doc.get("imageId"),
            }
    except Exception:
        return None


def probe_gcp_imds(timeout: float = 0.5) -> dict[str, Any] | None:
    """Probes GCP Compute Engine Metadata Service."""
    url = "http://metadata.google.internal/computeMetadata/v1/instance/?recursive=true"
    req = urllib.request.Request(url, headers={"Metadata-Flavor": "Google"})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            data = json.loads(resp.read().decode("utf-8"))
            zone = data.get("zone", "")
            zone_clean = zone.split("/")[-1] if zone else None
            machine = data.get("machineType", "")
            machine_clean = machine.split("/")[-1] if machine else None
            return {
                "provider": "GCP",
                "platform": "Google Compute Engine",
                "instance_id": str(data.get("id")),
                "instance_name": data.get("name"),
                "instance_type": machine_clean,
                "region": zone_clean,
                "zone": zone_clean,
            }
    except Exception:
        return None


def _detect_runtime() -> dict[str, Any]:
    """Gathers operating system and Python runtime facts."""
    return {
        "python_version": platform.python_version(),
        "python_implementation": platform.python_implementation(),
        "os": platform.system(),
        "os_release": platform.release(),
        "architecture": platform.machine(),
    }


def _detect_application() -> dict[str, Any]:
    """Detects framework, installed AI libraries, process ID, and hostname."""
    framework = _guess_framework()
    libraries = _detect_installed_libraries()

    container_image = os.environ.get("CONTAINER_IMAGE") or os.environ.get("IMAGE_NAME")

    return {
        "hostname": socket.gethostname(),
        "pid": os.getpid(),
        "framework": framework,
        "installed_libraries": libraries,
        "container_image": container_image,
        "sdk_version": "0.2.0",
    }


def _guess_framework() -> str:
    """Guesses web or agent framework from sys.modules or installed packages."""
    # Check loaded modules first
    loaded = sys.modules
    for fw in ["langchain", "crewai", "autogen", "semantic_kernel", "llama_index"]:
        if fw in loaded:
            return fw
    for fw in ["fastapi", "flask", "django"]:
        if fw in loaded:
            return fw

    # Check find_spec if not yet imported
    for fw in ["crewai", "langchain", "autogen", "llama_index", "fastapi", "flask", "django"]:
        try:
            if importlib.util.find_spec(fw) is not None:
                return fw
        except Exception:
            pass

    return "custom"


def _detect_installed_libraries() -> dict[str, str]:
    """Queries importlib.metadata for installed versions of known AI libraries."""
    detected = {}
    for lib_name in KNOWN_AI_LIBRARIES:
        try:
            ver = importlib.metadata.version(lib_name)
            detected[lib_name] = ver
        except (importlib.metadata.PackageNotFoundError, Exception):
            pass
    return detected


def _detect_llm_provider_hints() -> list[str]:
    """Checks for the presence of LLM API key environment variable NAMES only.

    NEVER returns the key value, only reports the provider name!
    """
    hints = []
    env = os.environ
    if "OPENAI_API_KEY" in env:
        hints.append("OpenAI")
    if "ANTHROPIC_API_KEY" in env:
        hints.append("Anthropic")
    if "GEMINI_API_KEY" in env or "GOOGLE_API_KEY" in env:
        hints.append("Google Gemini")
    if "AZURE_OPENAI_API_KEY" in env or "AZURE_OPENAI_ENDPOINT" in env:
        hints.append("Azure OpenAI")
    if "MISTRAL_API_KEY" in env:
        hints.append("Mistral AI")
    if "COHERE_API_KEY" in env:
        hints.append("Cohere")
    if "GROQ_API_KEY" in env:
        hints.append("Groq")
    if "OLLAMA_HOST" in env:
        hints.append("Ollama")
    if "AWS_BEDROCK_RUNTIME" in env or "AWS_DEFAULT_REGION" in env:
        hints.append("AWS Bedrock")
    return hints


def _detect_git_info() -> dict[str, Any]:
    """Extracts git repository, branch, and commit from CI environment variables."""
    env = os.environ

    # GitHub Actions
    if "GITHUB_REPOSITORY" in env:
        return {
            "repo_url": f"https://github.com/{env.get('GITHUB_REPOSITORY')}",
            "branch": env.get("GITHUB_REF_NAME"),
            "commit_sha": env.get("GITHUB_SHA"),
        }

    # GitLab CI
    if "CI_PROJECT_URL" in env:
        return {
            "repo_url": env.get("CI_PROJECT_URL"),
            "branch": env.get("CI_COMMIT_REF_NAME"),
            "commit_sha": env.get("CI_COMMIT_SHA"),
        }

    # Azure DevOps Pipelines
    if "BUILD_REPOSITORY_URI" in env:
        return {
            "repo_url": env.get("BUILD_REPOSITORY_URI"),
            "branch": env.get("BUILD_SOURCEBRANCHNAME"),
            "commit_sha": env.get("BUILD_SOURCEVERSION"),
        }

    # Generic or Vercel
    if "VERCEL_GIT_COMMIT_SHA" in env:
        return {
            "repo_url": env.get("VERCEL_GIT_REPO_URL"),
            "branch": env.get("VERCEL_GIT_COMMIT_REF"),
            "commit_sha": env.get("VERCEL_GIT_COMMIT_SHA"),
        }

    # Render Git
    if "RENDER_GIT_COMMIT" in env or "RENDER_GIT_REPO_SLUG" in env:
        repo_slug = env.get("RENDER_GIT_REPO_SLUG", "")
        repo_url = f"https://github.com/{repo_slug}" if repo_slug and not repo_slug.startswith("http") else repo_slug
        return {
            "repo_url": repo_url,
            "branch": env.get("RENDER_GIT_BRANCH"),
            "commit_sha": env.get("RENDER_GIT_COMMIT"),
        }

    return {}


def redact_secrets(data: Any) -> Any:
    """Recursively walks data and replaces any secret-looking keys or values."""
    if isinstance(data, dict):
        redacted = {}
        for k, v in data.items():
            if SECRET_KEY_PATTERN.search(str(k)):
                redacted[k] = "[REDACTED]"
            else:
                redacted[k] = redact_secrets(v)
        return redacted
    elif isinstance(data, list):
        return [redact_secrets(item) for item in data]
    elif isinstance(data, str):
        # Mask any accidental embedded token patterns
        if re.search(r"(sk-[a-zA-Z0-9]{20,}|act_live_[a-zA-Z0-9]{16,}|ghp_[a-zA-Z0-9]{20,})", data):
            return "[REDACTED]"
        return data
    return data
